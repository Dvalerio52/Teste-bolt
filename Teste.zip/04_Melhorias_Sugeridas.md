# Melhorias Sugeridas — Bolt Institucional

## Conteúdo e Navegação
1. **Separar “Ouvidoria” de “Contato”** com páginas/canais distintos e SLAs apropriados; manter “Fale Conosco” operacional.
2. **Sobre a Bolt → Informativo BoltCard**: criar/ligar landing clara com visão da adquirente, FAQs e CTAs (“Adquira sua Bolt”).

## Disponibilidade e Infraestrutura
3. **Corrigir Fale Conosco (404/erro)** — publicar página e validar rotas; adicionar monitoramento synthetic.
4. **Chat Online** — mover para subdomínio padrão (ex.: `chat.bolt.com.br`) em **HTTPS 443**, com fallback e status-page.
5. **Remover links com IP interno (192.168.x.x)** e substituir por URLs públicas versionadas (ex.: `https://bolt.com.br/docs/pld-vX.Y.pdf`).

## Segurança & Compliance
6. **Revisar classificação do PDF de Segurança** — publicar versão “Pública” (sanitizada) e manter versão restrita no ambiente interno.
7. **Carimbo de versão e data** nos PDFs públicos; responsável e contato de compliance.
8. **Headers de segurança** (HSTS, X-Content-Type-Options, etc.) e política de privacidade/termos visíveis.

## UX e Acessibilidade
9. **Estados de foco/teclado** e contrastes nos links do rodapé; rótulos descritivos para tecnologias assistivas.
10. **Página de PLD** — inverter lógica: apresentar resumo + botão “Baixar PDF” com metadados (tamanho, versão).

## Manutenibilidade
11. **Testes automatizados de links** no CI/CD para impedir deploy com URLs quebradas.
12. **Observabilidade** — alertas quando páginas de contato/ombudsman ficam indisponíveis.
