# Bugs — Bolt Institucional (bolt.com.br)
Data: 2025-08-25
Ambiente: Web (Desktop), Navegação pública — URLs analisadas diretamente.

## Sumário dos principais achados
1. **[Fale Conosco indisponível / link quebrado]** — `https://bolt.com.br/publico/faleConosco` retorna erro (página não abre).
2. **[PLD – link aponta para IP interno]** — Em `https://bolt.com.br/politicas_internas` o link **“clique aqui”** direciona para `http://192.168.0.33` (inacessível fora da rede).
3. **[Atendimento online indisponível]** — Link do “Atendimento online” aponta para `https://chatbrasilcard.grupoadrianocobuccio.com.br:9120` (porta/serviço não acessível publicamente).
4. **[Ouvidoria e Contato convergem para o mesmo destino]** — Ambos direcionam para “Fale Conosco”. Com o item 1 indisponível, nenhum canal funcional permanece.
5. **[Política de Segurança Cibernética – PDF classificado como ‘Restrita’ exposto publicamente]** — O PDF acessível pelo site está rotulado “Restrita – Circulação Interna” (potencial problema de confidencialidade / governança de documentos).
6. **[‘Sobre a Bolt’ não atende expectativa do requisito]** — Requisito informa “redirecionar para informativo da BoltCard”; atualmente é apenas uma âncora/seção na home.

---

## Detalhamento por bug

### BUG-01 — Fale Conosco indisponível
**Requisito**: “Ouvidoria” e “Contato” devem redirecionar para a guia **Fale conosco**; todos os meios devem iniciar contato com atendimento ao cliente.  
**Caminho**: Rodapé › Institucional › **Ouvidoria** / **Contato**  
**URL**: `https://bolt.com.br/publico/faleConosco`  
**Passos para reproduzir**:
1. Acessar `https://bolt.com.br/`.
2. No rodapé, clicar em **Ouvidoria** ou **Contato** (ambos apontam para Fale Conosco).
3. A página não abre (erro).
**Resultado atual**: Página indisponível/erro.  
**Resultado esperado**: Página **Fale Conosco** carregando com canais funcionais (formulário, e-mail, telefone e/ou WhatsApp).  
**Severidade**: Alta (bloqueia canais de atendimento/ombudsman).  
**Evidências**: link exibido no HTML/rodapé; tentativa direta de abrir `https://bolt.com.br/publico/faleConosco` retorna erro.

---

### BUG-02 — PLD (Política e Normas Internas) com link para IP interno
**Requisito**: “Fornece acesso às Políticas e Normas Internas de PLD dentro de um PDF”.  
**Caminho**: Rodapé › Institucional › **Política e Normas Internas de PLD**  
**URL de índice**: `https://bolt.com.br/politicas_internas`  
**Link interno exibido**: “clique aqui” → `http://192.168.0.33`  
**Passos para reproduzir**:
1. Acessar `https://bolt.com.br/politicas_internas`.
2. Clicar em **clique aqui**.
**Resultado atual**: Link aponta para IP da rede interna (`192.168.0.33`) — inacessível ao público; download do PDF falha.  
**Resultado esperado**: Link público (HTTPS/domínio da organização) com PDF acessível.  
**Severidade**: Alta (impede acesso à política regulatória ao público).  
**Observação**: Além de indisponibilidade, exposição de IP interno pode revelar topologia de rede.

---

### BUG-03 — Atendimento online indisponível
**Requisito**: “Iniciar atendimento com suporte ‘Bolt’”.  
**Caminho**: Header/Rodapé › **Atendimento online**  
**URL**: `https://chatbrasilcard.grupoadrianocobuccio.com.br:9120`  
**Passos para reproduzir**:
1. Acessar `https://bolt.com.br/`.
2. Clicar em **Atendimento online**.
**Resultado atual**: Serviço/porta não acessível publicamente; atendimento não inicia.  
**Resultado esperado**: Canal de chat acessível (via web ou widget).  
**Severidade**: Alta (canal síncrono de suporte indisponível).

---

### BUG-04 — Ouvidoria e Contato apontam para o mesmo destino
**Requisito**: “Ouvidoria” e “Contato” devem oferecer meios para contato com atendimento ao cliente; **Ouvidoria** tipicamente exige canal específico (manifestação formal).  
**Caminho**: Rodapé › Institucional › **Ouvidoria** / **Contato**  
**Comportamento atual**: Ambos apontam para **Fale Conosco** (ver BUG-01).  
**Impacto**: Reduz clareza e conformidade com boas práticas de SAC/Ouvidoria (Lei do SAC/ANPD/BCB, conforme o caso).  
**Severidade**: Média.

---

### BUG-05 — Política de Segurança Cibernética: PDF rotulado como “Restrita – Circulação Interna” está público
**Requisito**: Página deve “fornecer acesso às Políticas de segurança Cibernética dentro de um PDF”.  
**Caminho**: Rodapé › Institucional › **Política de Segurança Cibernética**  
**URL da página**: `https://bolt.com.br/politica_seguranca`  
**Link do PDF**: `https://grupoadrianocobuccio.com.br/images/brasilcard/Politica_de_Seguranca.pdf`  
**Conteúdo do PDF**: Capa indica *“Classificação: Restrita – Circulação Interna; Versão: V.2 — 18/02/2022”*.  
**Resultado atual**: Documento classificado como interno está disponível ao público e contém dados de estrutura/controles.  
**Resultado esperado**: Publicar versão sanitizada/classificada como “Pública” ou um resumo executivo, ou ajustar a classificação.  
**Severidade**: Média (risco de governança/segurança da informação).

---

### BUG-06 — ‘Sobre a Bolt’ não redireciona para informativo “BoltCard” (mismatch de requisito)
**Requisito**: “Sobre a Bolt → Redirecionar para informativo da ‘BoltCard’”.  
**Caminho**: Header/Rodapé › **Sobre a Bolt**  
**URL**: `https://bolt.com.br/` (âncora de seção “Sobre a Bolt”).  
**Resultado atual**: Permanece na mesma página (seção).  
**Resultado esperado**: Abrir uma página/landing “BoltCard” com informativo dedicado.  
**Severidade**: Baixa (conteúdo existe, mas não atende exatamente o requisito).

---

## Riscos e observações gerais
- Indisponibilidade dos principais canais de contato reduz confiança e pode afetar requisitos regulatórios de atendimento/PLD.
- Uso de IP interno em hiperlink público expõe informação de infraestrutura e inviabiliza o acesso externo.
- Documento classificado como “Restrito” exposto publicamente pode contrariar a própria política de classificação e gestão documental.
