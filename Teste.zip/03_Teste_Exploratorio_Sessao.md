# Documento de Teste Exploratório — bolt.com.br
Data: 2025-08-25
Charter: Avaliar a seção **Institucional** da Bolt, validando navegação, disponibilidade, conformidade com os requisitos e acessibilidade dos documentos.

## Escopo
- Itens: Sobre a Bolt, Grupo Adriano Cobuccio, Atendimento online, Ouvidoria, Contato, Política de Segurança Cibernética, Política e Normas Internas de PLD.
- Páginas de apoio: landing “Adquira sua Bolt”, Área do Lojista (apenas navegação superficial).

## Notas de Sessão
- **Tempo**: 60–90 min (estimado) focado na navegação pública.
- **Dados**: Nenhum login; apenas links públicos.

## Observações
- Footer apresenta a seção **Institucional** com todos os itens requeridos.
- "Grupo Adriano Cobuccio" direciona corretamente para `https://grupoadrianocobuccio.com.br/`.
- "Política de Segurança Cibernética" carrega página `https://bolt.com.br/politica_seguranca` com link para PDF hospedado em domínio do grupo; PDF indica classificação **Restrita – Circulação Interna (V.2 – 18/02/2022)**.
- "Política e Normas Internas de PLD" carrega página `https://bolt.com.br/politicas_internas` porém o link do PDF aponta para **IP interno (192.168.0.33)** — indisponível publicamente.
- "Ouvidoria" e "Contato" apontam para `.../publico/faleConosco`, página indisponível no momento do teste.
- "Atendimento online" aponta para host na porta **9120** — serviço não acessível publicamente.
- "Sobre a Bolt" é uma âncora na home; requisito menciona redirecionar para informativo “BoltCard”.

## Bugs catalogados
- Ver arquivo **01_Bugs_Bolt_Institucional.md** (6 itens).

## Riscos / Questões Abertas
- Conformidade regulatória (ex.: disponibilização pública de políticas, canal de ouvidoria).
- Governança documental (classificação do PDF de Segurança).
- Observabilidade/monitoramento (links quebrados não detectados?).

## Ideias de Teste Futuras
- Testes funcionais do chat (quando disponível).
- Verificação de acessibilidade (WCAG) e responsividade.
- Checagem de SEO/broken links site-wide.
